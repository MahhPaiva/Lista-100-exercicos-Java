package listadeexercicios100;

public class ExFuncoes {
    
    //Exercício 95
    public static int Somador2(int num1, int num2) {
        return (num1 + num2);
    }
    
    //Exercício 96
    public static Double Media(double n1, double n2) {
        return ((n1 + n2)/2);
    }
    
    //Exercício 97
    public static int Maior(int num1, int num2, int num3) {
        if (num1 > num2 && num1 > num3){
            return num1;
        }else if (num2 > num1 && num2 > num3){
            return num2;
        }else{
            return num3;
        }
    }
    
    //Exercício 98
    
    
    //Exercício 99
    
    
    //Exercício 100
    
}
